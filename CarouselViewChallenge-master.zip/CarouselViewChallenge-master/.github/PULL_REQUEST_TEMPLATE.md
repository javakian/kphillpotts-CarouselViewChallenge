## Submission description

_Use this area to describe your submission. Screenshots are appreciated and GIFs (with a hard "g") or video clips will get bonus points!_

### What went well

_This is self-explanatory. Let us know what you liked about using the CarouselView when creating this submission._

### What didn't go well

_What didn't go well, and why? How can we improve it? Please provide as much detail as possible!_

### Missing or desired things

_Fill this with any missing or desired things and how they impact you._

### Anything else

_If we missed anything, feel free to mention it here._

### Take out a survey for some goodies

_Please visit this [link](https://www.surveymonkey.com/r/KVF5X6G) to take a survey. If you provide your contact information, we'll send you some swag!_
